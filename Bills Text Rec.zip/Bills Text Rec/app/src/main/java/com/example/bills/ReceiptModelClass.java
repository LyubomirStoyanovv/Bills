package com.example.bills;

import android.graphics.Bitmap;

public class ReceiptModelClass {

    Bitmap receiptImage;

    public ReceiptModelClass(Bitmap receiptImage) {
        this.receiptImage = receiptImage;
    }

    public void setReceiptImage(Bitmap receiptImage) {
        this.receiptImage = receiptImage;
    }
    public Bitmap getReceiptImage() {
        return receiptImage;
    }
}
