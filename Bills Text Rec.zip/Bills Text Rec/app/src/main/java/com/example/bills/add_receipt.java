package com.example.bills;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.os.Environment.getExternalStoragePublicDirectory;

public class add_receipt extends AppCompatActivity {

    private DatabaseHelperTest db;
    private ImageView receipt;
    private TextView receiptText;
    private Button btnAddReceipt;
    private Button btnTakePic;
//    static final int REQUEST_IMAGE_CAPTURE = 1;
    private Button detectText;
    String pathToFile;
    Cursor cursor;

    private static final int PICK_RECEIPT_REQUEST = 100;
    private Uri receiptFilePath;
    private Bitmap receiptImageToStore;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_receipt);

        db = new DatabaseHelperTest(this);
        receipt = (ImageView) findViewById(R.id.receiptImage);

        Intent intent = getIntent();
        String user_email = intent.getStringExtra("user_email");
        String category_name = intent.getStringExtra("category_name");
        Integer expense_id = intent.getIntExtra("expense_id", 0);

        Cursor cursor = db.getReceipt(user_email, category_name, expense_id);
        Toast.makeText(getApplicationContext(),"Pictures saved: "+Integer.toString(cursor.getCount()), Toast.LENGTH_SHORT).show();
        if(cursor.getCount() == 0){

            Toast.makeText(getApplicationContext(), "No data", Toast.LENGTH_SHORT);

        }else {

            Toast.makeText(getApplicationContext(),Integer.toString(cursor.getCount()), Toast.LENGTH_SHORT).show();

            cursor.moveToFirst();
            byte[] receiptBytes = cursor.getBlob(0);
            Bitmap receiptToDisplay = BitmapFactory.decodeByteArray(receiptBytes, 0, receiptBytes.length);
            receipt.setImageBitmap(receiptToDisplay);

        }

        receiptText = (TextView) findViewById(R.id.viewText);
        btnAddReceipt = (Button) findViewById(R.id.addReceipt);

        receipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, PICK_RECEIPT_REQUEST);
            }
        });

        btnTakePic = (Button) findViewById(R.id.takePicture);

        if(ContextCompat.checkSelfPermission(add_receipt.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(add_receipt.this, new String[]{Manifest.permission.CAMERA}, 200);
        }

        btnTakePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                dispatchTakePictureIntent();
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 200);
            }
        });


        btnAddReceipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                storeReceipt();
            }
        });

        detectText = (Button) findViewById(R.id.detectTextBtn);


    }

//    private void dispatchTakePictureIntent() {
//        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        try {
//            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
//        } catch (ActivityNotFoundException e) {
//            // display error state to the user
//        }
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == PICK_RECEIPT_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

                receiptFilePath = data.getData();
                receiptImageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(), receiptFilePath);

                receipt.setImageBitmap(receiptImageToStore);
                FirebaseVisionImage firebaseVisionImage = FirebaseVisionImage.fromBitmap(receiptImageToStore);
                FirebaseVision firebaseVision = FirebaseVision.getInstance();
                FirebaseVisionTextRecognizer firebaseVisionTextRecognizer = firebaseVision.getOnDeviceTextRecognizer();
                Task<FirebaseVisionText> task = firebaseVisionTextRecognizer.processImage(firebaseVisionImage);
                task.addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
                    @Override
                    public void onSuccess(FirebaseVisionText firebaseVisionText) {
                        String s = firebaseVisionText.getText();
                        receiptText.setText(s);
                    }
                });
                task.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

            }
            if(requestCode == 200){

                receiptImageToStore = (Bitmap)data.getExtras().get("data");
                receipt.setImageBitmap(receiptImageToStore);
                FirebaseVisionImage firebaseVisionImage = FirebaseVisionImage.fromBitmap(receiptImageToStore);
                FirebaseVision firebaseVision = FirebaseVision.getInstance();
                FirebaseVisionTextRecognizer firebaseVisionTextRecognizer = firebaseVision.getOnDeviceTextRecognizer();
                Task<FirebaseVisionText> task = firebaseVisionTextRecognizer.processImage(firebaseVisionImage);
                task.addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
                    @Override
                    public void onSuccess(FirebaseVisionText firebaseVisionText) {
                        String s = firebaseVisionText.getText();
                        receiptText.setText(s);
                    }
                });
                task.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });


            }
        } catch (Exception e) {

            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    public void storeReceipt() {

        try {

            Intent intent = getIntent();
            String user_email = intent.getStringExtra("user_email");
            String category_name = intent.getStringExtra("category_name");
            Integer expense_id = intent.getIntExtra("expense_id", 0);
            Cursor cursor = db.getReceipt(user_email, category_name, expense_id);
            Toast.makeText(getApplicationContext(), "expense_id"+expense_id, Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(), "Before drawable check", Toast.LENGTH_SHORT).show();



            if(receipt.getDrawable()!=null) {

                Toast.makeText(getApplicationContext(), "Some text", Toast.LENGTH_SHORT).show();
                if (cursor.getCount() > 0) {
                    Toast.makeText(getApplicationContext(), "A receipt already stored", Toast.LENGTH_SHORT).show();
                    Boolean updateReceipt = db.updateImage(receiptImageToStore, user_email, category_name, expense_id);
                    if (updateReceipt == true) {

                        Toast.makeText(getApplicationContext(), "ReceiptImage updated", Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(getApplicationContext(), "update failed", Toast.LENGTH_SHORT).show();
                    }
                }else {

                    Toast.makeText(getApplicationContext(), "It should store", Toast.LENGTH_SHORT).show();
                    Boolean insert = db.storeImage(receiptImageToStore, user_email, category_name, expense_id);

                    if (insert == true) {

                        Toast.makeText(getApplicationContext(), "ReceiptImage added", Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        } catch (Exception e) {

//            Toast.makeText(getApplicationContext(), "Something went wron. Try again.", Toast.LENGTH_SHORT).show();
        }

    }
}
